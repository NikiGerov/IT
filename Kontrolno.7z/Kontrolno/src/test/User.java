package test;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="user")
@XmlAccessorType(XmlAccessType.FIELD)
public class User {
	
	private String name;
	private String room;
	private String duration;
	
	public User() {}
	
	public User(String name, String room, String duration){
		this.name = name;
		this.room = room;
		this.duration = duration;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getRoom() {
		return room;
	}
	
	public void setRoom(String room) {
		this.room = room;
	}

	public String getDuration() {
		return duration;
	}
	
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
//	public boolean hasPassword(User user) {
//		if(user.getPass() != null) {
//			return true;
//		}
//		return false;
//	}

	@Override
	public String toString() {
		return "User [name: " + name + ", room: " + room + ", duration: " + duration + "]";
	}
	
	

}
