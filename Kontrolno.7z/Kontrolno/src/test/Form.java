package test;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;
 

public class Form extends SimpleTagSupport {
	public void doTag() throws JspException, IOException {
      JspWriter out = getJspContext().getOut();
      out.println("<div class=\"container\">\r\n" + 
      		"		<form name=\"my-form\" action=\"Register\" method=\"post\" onsubmit=\"return SubmitUser()\">\r\n" + 
      		"			<div class=\"name-container\">\r\n" + 
      		"				<label for=\"name\">Name</label>\r\n" + 
      		"				<input type=\"text\" name=\"name\" id=\"name\" placeholder=\"name\">\r\n" + 
      		"				<div id=\"name-error\"></div>\r\n" + 
      		"			</div>\r\n" + 
      		"			<div class=\"room-container\">\r\n" + 
      		"				<label for=\"room\">Room</label>\r\n" + 
      		"				<input type=\"text\" name=\"room\" id=\"room\" placeholder=\"room\">\r\n" + 
      		"				<div id=\"room-error\"></div>\r\n" + 
      		"			</div>\r\n" + 
      		"			<div class=\"duration-container\">\r\n" + 
      		"				<label for=\"repeat\">Duration</label>\r\n" + 
      		"				<input type=\"text\" name=\"duration\" id=\"duration\" placeholder=\"duration\">\r\n" + 
      		"				<div id=\"duration-error\"></div>\r\n" + 
      		"			</div>\r\n" + 
      		"			<input type=\"submit\" name=\"submit-btn\" id=\"submit-btn\" value=\"Register\">\r\n" + 
      		"		</form>\r\n" + 
      		"		\r\n" + 
      		"	</div>");
   }
}