package test;

import java.util.HashMap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;


@XmlRootElement(name="users")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({User.class})
public class UserStorage {
	//@XmlElement(name = "user")
	private HashMap<String, User> users;
	
	public UserStorage() {}
	
	public HashMap<String, User> getUserStorage(){
		return users;
	}
	public void setUsers(HashMap<String, User> users) {
        this.users = users;
    }
	
	public void addUser (User user) {
		users.put(user.getName(), user);
	}
	
//	public boolean hasUsersWithEmail(String email) {
//		return users.containsKey(email);
//	}
//	
//	public void Save(User user) {
//		
//	}

}
