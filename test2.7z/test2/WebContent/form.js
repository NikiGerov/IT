let users = [
	{
		username: 'Martin',
		password: 'bbbbbbbB',
		age: 'Yes',
		terms: 'Yes'
	},
	{
		username: 'Ahmed',
		password: 'eeee',
		age: 'Yes',
		terms: 'Yes'
	}
];



ClearUsernameError = () => {
	if(username.value.length !== 0){
		username_error.innerHTML = '';
		return true;
	}
}
ClearPasswordError = () => {
	if(password.value.length !== 0){
		password_error.innerHTML = '';
		return true;
	}
}
ClearRepeatPasswordError = () => {
	if(password.value === repeat.value){
		repeat_error.innerHTML = '';
		return true;
	}
}
ClearCheckboxAgeError = () => {
	if (isAgeChecked.checked){
		age_error.innerHTML = '';
		return true;
	}
}
ClearCheckboxAcceptError = () => {
	if (isAccepted.checked){
		accept_error.innerHTML = '';
		return true;
	}
}

let username = document.getElementById('username');
let password = document.getElementById('password');
let repeat = document.getElementById('repeat');
let isAgeChecked = document.getElementById('age');
let isAccepted = document.getElementById('accept');


let username_error = document.getElementById('username-error');
let password_error = document.getElementById('password-error');
let repeat_error = document.getElementById('repeat-error');
let age_error = document.getElementById('age-error');
let accept_error = document.getElementById('accept-error');


username.addEventListener('blur', ClearUsernameError, true);
password.addEventListener('blur', ClearPasswordError, true);
repeat.addEventListener('blur', ClearRepeatPasswordError, true);
isAgeChecked.addEventListener('blur', ClearCheckboxAgeError, true);
isAccepted.addEventListener('blur', ClearCheckboxAcceptError, true);

ValidateUsername = (username, username_error) => {
	if(username.value.length === 0){
		username_error.innerHTML = 'Please enter a username';
		username_error.style.color = 'red';
		return false;
	}else if(username.value.length < 7){
		username_error.innerHTML = 'Username is too short';
		username_error.style.color = 'red';
		return false;
	}
	return true;
}

ValidatePassword = (pass, pass_error) => {
	if(pass.value.length === 0){
		pass_error.innerHTML = 'Please enter a password';
		pass_error.style.color = 'red';
		return false;
	}else if(pass.value.length < 4){
		pass_error.innerHTML = 'Password too short';
		pass_error.style.color = 'red';
		return false;
	}else if(pass.value.search(/[a-z]/) < 0){
		pass_error.innerHTML = 'Password must contain at least one lowercase letter';
		pass_error.style.color = 'red';
		return false;
	}else if(pass.value.search(/[A-Z]/) < 0){
		pass_error.innerHTML = 'Password must contain at least one uppercase letter';
		pass_error.style.color = 'red';
		return false;
	}
	return true;
}

ArePasswordsEqual = (pass, repeat_pass, repeat_pass_error) => {
	if(pass.value != repeat_pass.value){
		repeat_pass_error.innerHTML = 'Passwords must be equal';
		repeat_pass_error.style.color = 'red';
		return false;
	}
	return true;
}

IsAdult = (age_check, age_err) => {
	if(!age_check.checked){
		age_err.innerHTML = 'Please check!';
		age_err.style.color = 'red';
		return false;
	}
	return true;
}

doAgree = (accepted, accept_err) => {
	if(!accepted.checked){
		accept_err.innerHTML = 'Please check!';
		accept_err.style.color = 'red';
		return false;
	}
	return true;
}

SubmitUser = () => {

	let hasError = false;
	if(!ValidateUsername(username, username_error)){
		hasError = true;
	}



	if(!ValidatePassword(password, password_error)){
		hasError = true;
	}


	if(!ArePasswordsEqual(password, repeat, repeat_error)){
		hasError = true;
	}


	if(!IsAdult(isAgeChecked, age_error)){
		hasError = true;
	}


	if(!doAgree(isAccepted, accept_error)){
		hasError = true;
	}
	
	if(!hasError){
		let ageAnswer = '';
		let termsAnswer = '';

		if(isAgeChecked.checked){
			ageAnswer = 'Yes';
		}else{
			ageAnswer = 'No';
		}

		if(isAccepted.checked){
			termsAnswer = 'Yes';
		}else{
			termsAnswer = 'No';
		}

		users.push({
			username: username.value,
			password: password.value,
			age: ageAnswer,
			terms: termsAnswer
		});

		renderUsers();
	}

	return false;
}

deleteRow = (o) => {
	let p=o.parentNode.parentNode;
    p.parentNode.removeChild(p);
}

renderUsers = () => {
	let tableBody = document.querySelector('tbody');

	tableBody.innerHTML = '';
	users.forEach(function(u){
		tableBody.innerHTML += 
		'<tr><td>' + u.username + '</td><td>' 
		+ u.password + '</td><td>' + u.age + '</td><td>'
		+ u.terms + '</td><td><input type="button" value="X" onclick="deleteRow(this)"></td></tr>';
	});
}

renderUsers();