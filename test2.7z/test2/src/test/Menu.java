package test;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;
 

public class Menu extends SimpleTagSupport {
	public void doTag() throws JspException, IOException {
      JspWriter out = getJspContext().getOut();
      out.println("<table>\r\n" + 
      		"	<tr>\r\n" + 
      		"		<td><a href=\"register.jsp\">Register</td>\r\n" + 
      		"		<td><a href=\"login.jsp\">Login</td>\r\n" + 
      		"		<td><a href=\"ShowUsers\">Show all users</td>\r\n" + 
      		"	</tr>\r\n" + 
      		"</table>");
   }
}