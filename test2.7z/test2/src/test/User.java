package test;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="user")
@XmlAccessorType(XmlAccessType.FIELD)
public class User {
	
	private String name;
	private String email;
	private String pass;
	
	public User() {}
	
	public User(String name, String email, String pass){
		this.name = name;
		this.email = email;
		this.pass = pass;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}
	
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public boolean hasPassword(User user) {
		if(user.getPass() != null) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "User [name: " + name + ", email: " + email + ", password: " + pass + "]";
	}
	
	

}
