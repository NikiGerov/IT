package test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	HashMap<String, User> map = new HashMap<String, User>();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		User user = new User();
//		user.setEmail("mail");
//		user.setName("niki");
//		user.setPass("pass");
//	    try {
//
//	        JAXBContext context = JAXBContext.newInstance(User.class);
//	        Marshaller marshaller = context.createMarshaller();
//
//	        /** output the XML in pretty format */
//	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
//
//	        /** display the output in the console */
//	        marshaller.marshal(user, System.out);
//	        
//	        /** put the XML to the file - will be used by the unmarshal example */
//	        marshaller.marshal(user, new File("C:\\Users\\User\\Desktop\\IT\\file.xml"));
//
//	    } catch (JAXBException e) {
//	        e.printStackTrace();
//	    }
		
	    //response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
        User user = new User();
        user.setEmail(request.getParameter("email"));
		user.setName(request.getParameter("user"));
		user.setPass(request.getParameter("pass"));
		
		request.setAttribute("user", user);
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/registeredUser.jsp");
        dispatcher.forward(request, response);
	 }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
//		User user = new User();
//		user.setEmail(request.getParameter("email"));
//		user.setName(request.getParameter("user"));
//		user.setPass(request.getParameter("pass"));
//		
//		
//		
//		File file = new File("C:\\Users\\User\\Desktop\\IT\\file.xml");
//		
//	    try {
//
//	        JAXBContext context = JAXBContext.newInstance(User.class);
//	        Marshaller marshaller = context.createMarshaller();
//
//	        /** output the XML in pretty format */
//	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
//
//	        /** display the output in the console */
//	        marshaller.marshal(user, System.out);
//	        
//	        /** put the XML to the file - will be used by the unmarshal example */
//	        if(file.exists()) {
//	        	file.delete();
//	        }
//	        marshaller.marshal(user, file);
//
//	    } catch (JAXBException e) {
//	        e.printStackTrace();
//	    }
		
		
		UserStorage users = new UserStorage();
		users.setUsers(map);

		users.addUser(new User(request.getParameter("email"),
								request.getParameter("user"),
								request.getParameter("pass")));

	    try {

	        JAXBContext context = JAXBContext.newInstance(UserStorage.class);
	        Marshaller marshaller = context.createMarshaller();

	        /** output the XML in pretty format */
	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

	        /** display the output in the console */
	        marshaller.marshal(users, System.out);
	        
	        /** put the XML to the file - will be used by the unmarshal example */
	        marshaller.marshal(users, new File("C:\\Users\\User\\Desktop\\IT\\file2.xml"));

	    } catch (JAXBException e) {
	        e.printStackTrace();
	    }
	}

}
