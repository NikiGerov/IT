package test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

/**
 * Servlet implementation class ShowUsers
 */
@WebServlet("/ShowUsers")
public class ShowUsers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowUsers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		try {
//
//	        JAXBContext context = JAXBContext.newInstance(User.class);
//
//	        Unmarshaller unmarshaller = context.createUnmarshaller();
//	        User user = (User) unmarshaller.unmarshal(new File("C:\\Users\\User\\Desktop\\IT\\file2.xml"));
//	        System.out.println(user);
//	        
//	        request.setAttribute("user", user);
//	        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/showUsers.jsp");
//	        dispatcher.forward(request, response);
//
//	    } catch (JAXBException e) {
//	        e.printStackTrace();
//	    }
		
		try {

			JAXBContext jaxbContext = JAXBContext.newInstance(UserStorage.class);
		    Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		    UserStorage users = (UserStorage) jaxbUnmarshaller.unmarshal( new File("C:\\Users\\User\\Desktop\\IT\\file2.xml") );
//		     
//		    for(String mail : users.getUserStorage().keySet())
//		    {
//		       
//		        System.out.println("Name is: " + users.getUserStorage().get(mail).getName());
//		        System.out.println("Email is: " + users.getUserStorage().get(mail).getEmail());
//		    }
//		    
		    request.setAttribute("users", users.getUserStorage());

	        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/showUsers.jsp");
	        dispatcher.forward(request, response);
		    

	    } catch (JAXBException e) {
	        e.printStackTrace();
	    }
		  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
