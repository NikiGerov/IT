package test;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;
 

public class CustomTag extends SimpleTagSupport {
	public void doTag() throws JspException, IOException {
      JspWriter out = getJspContext().getOut();
      out.println("<form method=\"POST\" action=\"Register\">\r\n" + 
      		"	<div>Username: <input type=\"text\" name=\"user\" id=\"user\"></div>\r\n" + 
      		"	<div>E-mail: <input type=\"text\" name=\"email\" id=\"email\"></div>\r\n" + 
      		"	<div>Password: <input type=\"password\" name=\"pass\" id=\"pass\"></div>\r\n" + 
      		"	<button type=\"submit\">Register</button>\r\n" + 
      		"	<a href=\"test/ShowUsers>asd</a>\r\n" + 
      		"</form>\r\n");
   }
}