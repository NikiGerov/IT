package servletsExmp;

import java.util.HashMap;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class UserStorage {
	@XmlElement(name = "user")
	HashMap<String, User> users;
	
	public void add (User user) {
		users.put(user.getEmail(), user);
	}
	
	public boolean hasUsersWithEmail(String email) {
		return users.containsKey(email);
	}
	
	public void Save(User user) {
		
	}

}
