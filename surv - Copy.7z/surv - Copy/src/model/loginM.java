package model;

public class loginM {
	
	private String Name;
	private String pass;
	
	public loginM(String N, String P)
	{
		this.setName(N);
		this.setPass(P);
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}

}
