package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.regM;

/**
 * Servlet implementation class registerServlets
 */
@WebServlet("/registerServlets")
public class registerServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registerServlets() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String numb = request.getParameter("phone");
		String pass = request.getParameter("pass");
		String email = request.getParameter("email");
		
		regM user = new regM(name, numb, pass, email);
		
		request.setAttribute("user", user);
		
		RequestDispatcher dispatch = request.getRequestDispatcher("/file.jsp"); //class
		
		dispatch.forward(request, response);
		
	}

}
